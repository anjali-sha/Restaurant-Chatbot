## intent:affirm
- yes
- yep
- yeah
- indeed
- that's right
- ok
- great
- right, thank you
- correct
- great choice
- sounds really good
- thanks
- Thanks

## intent:goodbye
- bye
- goodbye
- good bye
- stop
- end
- farewell
- Bye bye
- have a good one

## intent:greet
- hey
- howdy
- hey there
- hello
- hi
- good morning
- good evening
- dear sir
- Hi
- hola

## intent:restaurant_search
- i'm looking for a place to eat
- I want to grab lunch
- I am searching for a dinner spot
- I am looking for some restaurants in [delhi](location).
- I am looking for some restaurants in [Bangalore](location)
- show me [chinese](cuisine) restaurants
- show me [chines]{"entity": "cuisine", "value": "chinese"} restaurants in the [delhi](location)
- show me a [mexican](cuisine) place in the [centre](location)
- i am looking for an [indian](cuisine) spot called olaolaolaolaolaola
- search for restaurants
- anywhere in the [west](location)
- I am looking for [North Indian](cuisine) food
- I am looking a restaurant in [294328](location)
- in [Gurgaon](location)
- [South Indian](cuisine)
- [North Indian](cuisine)
- [American](cuisine)
- [Italian](cuisine)
- [Chinese]{"entity": "cuisine", "value": "chinese"}
- [chinese](cuisine)
- [Lithuania](location)
- Oh, sorry, in [Italy](location)
- in [delhi](location)
- I am looking for some restaurants in [Mumbai](location)
- I am looking for [mexican](cuisine)
- can you book a table in [pune](location) between [300](budgetmin) and [700](budgetmax) price range with [italian](cuisine) food for [four]{"entity": "people", "value": "4"} people
- i'm looking for a place in [Delhi](location) over [300]{"entity": "budgetmin", "value": "300"}
- find me a place in [delhi] (location) over [500](budgetmin)
- find me a place in [delhi] (location) under [500](budgetmax)
- i'm looking for a place in [Delhi](location) under [700]{"entity": "budgetmax", "value": "700"}
- i'm looking for a place in [Delhi](location) within [300]{"entity": "budgetmax", "value": "300"}
- i'm looking for a place in [Delhi](location) between [300](budgetmin) and [700](budgetmax)
- show me [chinese](cuisine) restaurants in [Delhi](location) within [700]{"entity": "budgetmax", "value": "700"}
- I am looking for [South indian](cuisine) food below [700]{"entity": "budgetmax", "value": "700"}
- find me a [mexican](cuisine) place in [Hyderabad](location) between [500](budgetmin) and [700](budgetmax)
- find me a place in [Hyderabad](location) for [two](people) under [1200]{"entity": "budgetmax", "value": "1200"}
- [central](location) [indian](cuisine) restaurant
- please help me to find restaurants in [pune](location)
- Please find me a restaurantin [bangalore](location)
- [mumbai](location)
- [bengaluru](location)
- show me restaurants
- please find me [chinese](cuisine) restaurant in [delhi](location)
- can you find me a [chinese](cuisine) restaurant
- [delhi](location)
- please find me a restaurant in [ahmedabad](location)
- please show me a few [italian](cuisine) restaurants in [bangalore](location)
- can you find me a good restaurant
- [Bangalore](location)
- I’m hungry. Looking out for some good restaurants
- Can you suggest some good restaurants in [delhi](location)
- I’m hungry. Looking out for some good [chinese](cuisine) restaurants in [chandigarh](location)
- yes. Please send it to [ahbcdj@dkj.com](emailid)
- My email id is [ahbcdj@dkj.com](emailid)
- [prannoyprashad@gmail.com]{"entity": "emailid", "value": "prannoyprashad@gmail.com"}
- [123anjali007@gmail.com](emailid)
- [South Indian]{"entity": "cuisine", "value": "south indian"}

## synonym:2
- two
- Two

## synonym:4
- four
- Four

## synonym:Bokaro Steel City
- Bokaro
- Bokaro St Cty
- bokaro

## synonym:Durg-Bhilai Nagar
- durg-bhilai nagar
- Bhilai Nagar
- Durg-Bhilai

## synonym:Hubli-Dharwad
- hubli-dharwad
- Hubli
- Dharwad

## synonym:Vasai-Virar City
- vasai-virar city
- vasai city
- Virar City

## synonym:agra
- Agra
- Agrah
- Agara

## synonym:ahmedabad
- Ahmedabad
- Ahmedbad
- Ahmeadbad

## synonym:ajmer
- Ajmer
- ajmr
- Ajmir

## synonym:aligarh
- Aligarh
- alligarh
- Aligadh

## synonym:allahabad
- Allahabad
- Alahabad
- Illahabad

## synonym:american
- American
- americn
- amrican

## synonym:amravati
- Amrvati
- Amravatti
- Amravati

## synonym:amritsar
- amratsar
- amaritsar
- Amritsar

## synonym:asansol
- asnsol
- asansole
- Asansol

## synonym:aurangabad
- Aurangabad
- arangbad
- aurangabd

## synonym:bangalore
- Bengaluru
- bengaluru
- Bangalore

## synonym:bareilly
- Bareilly
- barelly
- bareily

## synonym:belgaum
- Belgaum
- Belgam
- Belegaum

## synonym:bhavnagar
- Bhavnagar
- bhavanagar
- bhaavnagar

## synonym:bhiwandi
- Bhiwandi
- bhiwaandi
- biwandi

## synonym:bhopal
- Bhopal
- Bhopl
- bopal

## synonym:bhubaneswar
- Bhubaneswar
- Bhuvaneswar
- Bhubaneshwar

## synonym:bijapur
- Bijapur
- Bijpur
- Bijapoor

## synonym:bikaner
- Bikaner
- bikanear
- bykaner

## synonym:chandigarh
- Chandigarh
- Chandigadh
- Chandigar

## synonym:chennai
- chenai
- Chennai
- madras

## synonym:chinese
- chines
- Chinese
- Chines

## synonym:coimbatore
- Coimbatore
- koimbatore
- Coimbator

## synonym:cuttack
- Cuttack
- Kuttack
- Cuttak

## synonym:dehradun
- Dehradoon
- Doon
- Deharadun

## synonym:delhi
- New Delhi
- Delhi
- Dilli

## synonym:dhanbad
- Dhanbad
- Dhanbd
- Dhanabad

## synonym:durgapur
- Durgapur
- Durgapure
- Durgapoor

## synonym:erode
- Erode
- Erood
- Eroode

## synonym:faridabad
- Faridabad
- faridabaad
- Faridabd

## synonym:firozabad
- Firozabad
- Firozbad
- Firzabad

## synonym:ghaziabad
- Ghaziabad
- Gaziabad
- ghaziabaad

## synonym:gorakhpur
- Gorakhpur
- Gorakhpoor
- Gorakpur

## synonym:gulbarga
- Gulbarga
- Gulbarg
- Gulbrga

## synonym:guntur
- Guntur
- guntoor
- Gantur

## synonym:gurgaon
- Gurgaon
- Gurugaon
- Gurugram

## synonym:guwahati
- Guwahati
- Gowahati
- guhati

## synonym:gwalior
- Gwalior
- Gwaliar
- Ghwalior

## synonym:hyderabad
- Hyderabad
- hyderbad
- hyderabd

## synonym:indore
- Indore
- Indor
- indur

## synonym:italian
- Italian
- Italin
- Itlian

## synonym:jabalpur
- Jabalpur
- Jabalapur
- Jablpur

## synonym:jaipur
- Jaipur
- Jaypur
- Jaipure

## synonym:jalandhar
- Jalandhar
- Jalanadhar
- Jalandar

## synonym:jammu
- Jammu
- jamu
- jaamu

## synonym:jamnagar
- Jamnagar
- Jamanagar
- Jamnagr

## synonym:jamshedpur
- Jamshedpur
- jamshedpure
- Jamshedpoor

## synonym:jhansi
- Jhansi
- Jansi
- Jhanasi

## synonym:jodhpur
- Jodhpur
- Jodhpure
- Jodpur

## synonym:kakinada
- Kakinada
- Kakinaada
- Kakinad

## synonym:kannur
- Kannur
- Kanur
- Kanoor

## synonym:kanpur
- Kanpur
- Cawnpore
- Kaanpur

## synonym:kochi
- Kochi
- Cochi
- Cochin

## synonym:kolhapur
- Kolhapur
- Kohlapur
- Kolapur

## synonym:kolkata
- Kolkata
- Calcutta
- Kolkatta

## synonym:kollam
- Kollam
- Kolam
- Kolaam

## synonym:kota
- Kota
- Cota
- Kuta

## synonym:kottayam
- Kottayam
- Kottyam
- Kotayam

## synonym:kozhikode
- Kozhikode
- Kozhikod
- kozhi

## synonym:kurnool
- Kurnool
- Curnool
- Koornool

## synonym:lucknow
- Lucknow
- Lko
- Luknow

## synonym:ludhiana
- Ludhiana
- Ludiana
- ludiana

## synonym:madurai
- Madurai
- Madoorai
- Madhurai

## synonym:malappuram
- Malappuram
- Malapuram
- Mallappuram

## synonym:mangalore
- Mangalore
- Manglore
- Mangalor

## synonym:mathura
- Mathura
- Mathoora
- Matura

## synonym:meerut
- Meerut
- Merut
- Meruth

## synonym:mexican
- Mexicn
- Mexican
- mxican

## synonym:mid
- moderate

## synonym:moradabad
- Moradabad
- Moradabaad
- Moradbad

## synonym:mumbai
- Mumbai
- Bombai
- Bombay

## synonym:mysore
- Mysore
- Mysuru
- mysuru

## synonym:nagpur
- Nagpur
- Nagpoor
- Nagpor

## synonym:nanded
- Nanded
- Nandhed
- Nandead

## synonym:nashik
- Nashik
- Naashik
- Nasik

## synonym:nellore
- Nellore
- Nelloro
- Nelore

## synonym:noida
- Noida
- Greater Noida
- G. Noida

## synonym:north indian
- North Indian
- North indian
- north Indian

## synonym:palakkad
- Palakkad
- Palakad
- Palakaad

## synonym:patna
- Patna
- Pathna
- patana

## synonym:pondicherry
- Pondicherry
- Pondi
- Puducherry

## synonym:pune
- Poona
- Puna
- Pune

## synonym:raipur
- Raipur
- Raipore
- Raipure

## synonym:rajahmundry
- Rajahmundry
- Raajahmundry
- rajahmundri

## synonym:rajkot
- Rajkot
- Raajkot
- Rajakot

## synonym:ranchi
- Ranchi
- Rancih
- ranchy

## synonym:rourkela
- Rourkela
- Rorkela
- Rourekla

## synonym:salem
- Salem
- Selem
- Selam

## synonym:sangli
- Sangli
- Sanglih
- Saangli

## synonym:siliguri
- Siliguri
- Siligudi
- Silguri

## synonym:solapur
- Solapur
- Solahpur
- solapoor

## synonym:south indian
- South Indian
- South indian
- south Indian

## synonym:srinagar
- Srinagar
- shrinagar
- Srinagr

## synonym:sultanpur
- Sultanpur
- Sultanpoor
- Sultanapur

## synonym:surat
- Surat
- Soorat
- suraat

## synonym:thiruvananthapuram
- Thiruvananthapuram
- Trivandram
- Thiruvanantapuram

## synonym:thrissur
- Thrissur
- Thrisur
- Thirisur

## synonym:tiruchirappalli
- Tiruchirappalli
- Tiruchirapalli
- Trichy

## synonym:tirunelveli
- Tirunelveli
- Trunelveli
- Tirnelveli

## synonym:tiruppur
- Tiruppur
- Tirupur
- Tiruppor

## synonym:ujjain
- Ujjain
- Ujain
- Ujjan

## synonym:vadodara
- Vadodara
- Baroda
- Vadodra

## synonym:varanasi
- Varanasi
- Banaras
- Varansi

## synonym:vegetarian
- veggie
- vegg
- veg

## synonym:vijayawada
- Vijayawada
- Vijaiawada
- Vijaywada

## synonym:visakhapatnam
- Visakhapatnam
- Vizag
- Vishakhapatnam

## synonym:warangal
- Warangal
- Waarangal
- waarangal

## regex:emailid
- [A-z0-9._%+-]+@[A-z0-9.-]+\\.[A-z.]{2,4}

## regex:greet
- hey[^\s]*

## regex:pincode
- [0-9]{6}

## regex:budgetmin
- [0-9]{6}

## regex:budgetmax
- [0-9]{6}
