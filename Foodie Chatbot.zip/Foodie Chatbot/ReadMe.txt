
NLP Course Project - Building a Chatbot
Case Study - Foodie Chatbot

Institute: IIIT,Bangalore & upGrad

Course: PG Diploma in ML & AI (Batch: C12)

Submission Date: 15-JUN-2020

Submitted By: Prannoy Prashad (prannoyprashad@gmail.com)
              Anjali Sharma (123anjali007@gmail.com)

Problem Statement:

An Indian startup named 'Foodie' wants to build a conversational bot (chatbot) which can help users discover restaurants across 
several Indian cities. You have been hired as the lead data scientist for creating this product. 

The main purpose of the bot is to help users discover restaurants quickly and efficiently and to provide a good restaurant 
discovery experience. The project brief provided to you is as follows.

Goals of this Project:

NLU training: We used rasa-nlu-trainer to create more training examples for entities and intents. We tried using regex features 
and synonyms for extracting entities.

Build actions for the bot: We read through the Zomato API documentation to extract the features such as the average price for two 
people and restaurant’s user rating. We also need build an ‘action’ for sending emails from Python.

Creating more stories: We referred  to the sample conversational stories as provided. Our bot evaluated on something similar to 
the test stories shared.


Versions:

Using Python 3.7.4
Using Rasa 1.10.1
Using rasa-sdk 1.10.1
Using rasa-x 0.28.6 
Using scipy 1.4.1
Using tensorflow 2.1.1
Using conda 4.7.12
Using Windows 10

Important Note:

1. Please provide your email_id & password for sending emails to users which is hard coded in actions.py.

2. Assume that Foodie works only in Tier-1 and Tier-2 cities. You can use the current HRA classification of the cities from here. 
Under the section 'current classification' on this page, the table categorizes cities as X, Y and Z. Consider 'X ' cities as 
tier-1 and 'Y' as tier-2. 

2. The bot should be able to identify common synonyms of city names, such as Bangalore/Bengaluru, 
Mumbai/Bombay etc.

3. Cuisine Preference: Take the cuisine preference from the customer. The bot should list out the following six cuisine 
categories (Chinese, Mexican, Italian, American, South Indian & North Indian) and the customer can select any one out of that.

4. Average budget for two people: Segment the price range (average budget for two people) into three price categories: lesser 
than 300, 300 to 700 and more than 700. The bot should ask the user to select one of the three price categories.

5. While showing the results to the user, the bot should display the top 5 restaurants in a sorted order (descending) of the 
average Zomato user rating (on a scale of 1-5, 5 being the highest). 
The format should be: {restaurant_name} in {restaurant_address} has been rated {rating}.

6. Finally, the bot should ask the user whether he/she wants the details of the top 10 restaurants on email. If the user replies 'yes', the bot should ask for user’s email id and then send it over email. Else, just reply with a 'goodbye' message. The mail should have the following details for each restaurant:
Restaurant Name
Restaurant locality address
Average budget for two people
Zomato user rating